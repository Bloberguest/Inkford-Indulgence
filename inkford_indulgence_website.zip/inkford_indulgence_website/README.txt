# Inkford Indulgence website

Open `index.html` in a browser to preview the site.

To publish it free:
1. Create a free GitHub account.
2. Create a new repository named `inkford-indulgence`.
3. Upload `index.html` (and this README if you want).
4. In the repository settings, enable GitHub Pages from the `main` branch.
5. GitHub will give you a free website address.

The site is responsive and includes the Inkford Indulgence story, all 15 flavours, tub prices, delivery areas and contact details.

The reviews section has intentionally not been added yet because the review text has not been supplied.
